CREATE DATABASE IF NOT EXISTS `siiro`;

USE `siiro`;

DROP TABLE IF EXISTS `ais_berangkat`;

CREATE TABLE `ais_berangkat` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `kelompok` varchar(255) NOT NULL,
  `ketua` varchar(255) NOT NULL,
  `anggota` varchar(255) NOT NULL,
  `nomor_penerbangan` varchar(255) NOT NULL,
  `tanggal_berangkat` date NOT NULL,
  `keterangan` text NOT NULL,
  `periode_tahun` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;




DROP TABLE IF EXISTS `ais_kelompok`;

CREATE TABLE `ais_kelompok` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nama` varchar(255) NOT NULL,
  `jenis` varchar(255) NOT NULL,
  `keterangan` text NOT NULL,
  `periode_tahun` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;

INSERT INTO `ais_kelompok` VALUES("1","Sistem Infomrasi 1","","","0");
INSERT INTO `ais_kelompok` VALUES("2","Panitia","","","0");
INSERT INTO `ais_kelompok` VALUES("4","TI 1","","","2018");
INSERT INTO `ais_kelompok` VALUES("5","TI 2","","","2018");
INSERT INTO `ais_kelompok` VALUES("6","TI 3","","","2018");
INSERT INTO `ais_kelompok` VALUES("7","TI 4","","","2018");
INSERT INTO `ais_kelompok` VALUES("8","TI 5","","","2018");
INSERT INTO `ais_kelompok` VALUES("9","TI 6","","","2018");
INSERT INTO `ais_kelompok` VALUES("10","TI 7","","","2018");
INSERT INTO `ais_kelompok` VALUES("11","TI 8","","","2018");
INSERT INTO `ais_kelompok` VALUES("12","TI 9","","","2018");
INSERT INTO `ais_kelompok` VALUES("13","TI 10","","","2018");



DROP TABLE IF EXISTS `ais_pembayaran`;

CREATE TABLE `ais_pembayaran` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `peserta_id` varchar(255) NOT NULL,
  `jumlah` int(11) NOT NULL,
  `tanggal` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;




DROP TABLE IF EXISTS `ais_peserta`;

CREATE TABLE `ais_peserta` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `kelompok` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `nama` varchar(255) NOT NULL,
  `tanggal_lahir` date NOT NULL,
  `tempat_lahir` varchar(255) NOT NULL,
  `jurusan` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `nomor_hp` varchar(255) NOT NULL,
  `alamat` varchar(255) NOT NULL,
  `nomor_ktp` varchar(255) NOT NULL,
  `scan_ktp` varchar(255) NOT NULL,
  `nomor_paspor` varchar(255) NOT NULL,
  `scan_paspor` varchar(255) NOT NULL,
  `periode_tahun` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=latin1;

INSERT INTO `ais_peserta` VALUES("9","4","Peserta","M. Anton Permana","0000-00-00","","Teknik Informatika","anton.permana@nusaputra.ac.id","","","","","","","2018");
INSERT INTO `ais_peserta` VALUES("10","4","Peserta","Agham Rahmadi Setiawan","0000-00-00","","Teknik Informatika","agham.rahmadi@nusaputra.ac.id","","","","","","","2018");
INSERT INTO `ais_peserta` VALUES("12","4,13","Pembimbing","Dedi Supardi, ST,M.Kom","0000-00-00","","","dedi.supardi@nusaputra.ac.id","","","","","","","2018");
INSERT INTO `ais_peserta` VALUES("13","4","Peserta","Aryo Ardianto","0000-00-00","","Teknik Informatika","aryo.ardianto@nusaputra.ac.id","","","","","","","2018");
INSERT INTO `ais_peserta` VALUES("14","4","Peserta","Aditya Rachmawan","0000-00-00","","Teknik Informatika","aditya.rachmawan@nusaputra.ac.id","","","","","","","2018");



DROP TABLE IF EXISTS `ais_pulang`;

CREATE TABLE `ais_pulang` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `kelompok` varchar(255) NOT NULL,
  `ketua` varchar(255) NOT NULL,
  `anggota` varchar(255) NOT NULL,
  `nomor_penerbangan` varchar(255) NOT NULL,
  `tanggal_pulang` date NOT NULL,
  `keterangan` text NOT NULL,
  `periode_tahun` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `ais_pulang` VALUES("1","Kel 1","12","10,13,15","","0000-00-00","","2018");



DROP TABLE IF EXISTS `ais_setting`;

CREATE TABLE `ais_setting` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nama` varchar(255) NOT NULL,
  `tahun` varchar(255) NOT NULL,
  `negara` varchar(255) NOT NULL,
  `tanggal` date NOT NULL,
  `biaya_travel` int(11) NOT NULL,
  `biaya_conference` int(11) NOT NULL,
  `keterangan` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `ais_setting` VALUES("1","ICCED 2018","2018","Thailand","2018-09-06","5600000","3000000","");



DROP TABLE IF EXISTS `conference_email`;

CREATE TABLE `conference_email` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `negara` varchar(255) NOT NULL,
  `nama_university` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `alamat` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=latin1;

INSERT INTO `conference_email` VALUES("2","Thailand","Mahidol University","opwww@mahidol.ac.th","999 Phutthamonthon Sai 4 Rd, Tambon Salaya, Amphoe Phutthamonthon, Chang Wat Nakhon Pathom 73170, Thailand");
INSERT INTO `conference_email` VALUES("3","Thailand","Chulalongkorn University","int.off@chula.ac.th","Mahatheerarachanusorn Building, Chulalongkorn University, 254 Phayathai Rd, Wang Mai, Pathum Wan, Bangkok 10330, Thailand");
INSERT INTO `conference_email` VALUES("4","Thailand","Chiang Mai University","prcmu239@gmail.com","Su Thep, Mueang Chiang Mai District, Provinsi Chiang Mai 50200, Thailand");
INSERT INTO `conference_email` VALUES("5","Thailand","Kasetsart University","www@ku.ac.th","50 Thanon Ngamwongwan, Khwaeng Lat Yao, Khet Chatuchak, 10900, Thailand");
INSERT INTO `conference_email` VALUES("6","Thailand","Khon Kaen University","jittkr@kku.ac.th","Khon Kaen University (KKU) 123 Moo 16 Mittapap Rd., Nai-Muang, Muang District, Khon Kaen 40002,Thailand");
INSERT INTO `conference_email` VALUES("7","Thailand","Prince of Songkla University","psu-international@psu.ac.th","15 Karnjanavanich Rd., Hat Yai, Songkhla 90110  Tel: 66 74 282000 (Operator), 66 74 446824 (International Office). Fax: 66 74 446825");
INSERT INTO `conference_email` VALUES("8","Thailand","Suranaree University of Technology","pr@sut.ac.th","111, Thanon Maha Witthayalai, Suranari, Mueang Nakhon Ratchasima District, Nakhon Ratchasima 30000, Thailand");
INSERT INTO `conference_email` VALUES("9","Thailand","King Mongkut\'s University of Technology Thonburi","info@kmutt.ac.th","126 Pracha Uthit Rd., Bang Mod, Thung Khru, Bangkok 10140, Thailand");
INSERT INTO `conference_email` VALUES("10","Thailand","Thammasat University","cia@tbs.tu.ac.th","Khwaeng Phra Borom Maha Ratchawang, Khet Phra Nakhon, Krung Thep Maha Nakhon 10200, Thailand");
INSERT INTO `conference_email` VALUES("11","Thailand","Naresuan University","international@nu.ac.th","Naresuan University Phitsanulok 65000 Thailand Telephone: +66 5596 1000 Fax: +66 5596 1103");
INSERT INTO `conference_email` VALUES("12","Thailand","King Mongkut\'s Institute of Technology Ladkrabang","pr.kmitl@kmitl.ac.th","KMITL Lat Krabang, Bangkok 10520, Thailand");
INSERT INTO `conference_email` VALUES("13","Thailand","Asian Institute of Technology Thailand","omco@ait.ac.th","58 Moo 9 - Paholyothin Highway, Khlong Nueng, Pathum Thani 12120, Thailand");
INSERT INTO `conference_email` VALUES("14","Thailand","Srinakharinwirot University","ird@swu.ac.th","Office of the President, Srinakharinwirot University 114 Sukhumvit 23, Wattana District, Bangkok 10110, THAILAND");
INSERT INTO `conference_email` VALUES("15","Thailand","Burapha University","wmaster@buu.ac.th","Burapha University, 169 Longhaad Bangsaen Road, Saensook, Mueang, ChonBuri 20131");
INSERT INTO `conference_email` VALUES("16","Thailand","Mahasarakham University","iroffice@msu.ac.th","Khamriang Sub-District,  Kantarawichai District,  Maha Sarakham 44150 Thailand");
INSERT INTO `conference_email` VALUES("17","Thailand","Silpakorn University","SOPONPONGPIPAT_N@SU.AC.TH","31 Na Phra Lan Rd, Phra Borom Maha Ratchawang, Phra Nakhon,10200, Thailand");
INSERT INTO `conference_email` VALUES("18","Thailand","Mae Fah Luang University","inter@mfu.ac.th","333 Moo 1, Tha Suea Muang Amphoe Mueang Chiang Rai, Chang Wat Chiang Rai 57100, Thailand");
INSERT INTO `conference_email` VALUES("19","Thailand","King Mongkut\'s University of Technology North Bangkok","icop@kmutnb.ac.th","1518 Pracharat 1 Road,Wongsawang, Bangsue, Bangkok 10800  Tel. +66 2 555-2000 Fax +66 2 587-4350");
INSERT INTO `conference_email` VALUES("20","Thailand","Rangsit University","rsuip@rsu.ac.th","52/347 Muang-Ake Phaholyothin Road Lak-Hok Muang Pathum Thani 12000, Thailand");
INSERT INTO `conference_email` VALUES("21","Thailand","Mahanakorn University of Technology","inter@mutacth.com","140 Cheum-Sampan Road,  Nongchok, Bangkok 10530");
INSERT INTO `conference_email` VALUES("22","Thailand","Assumption University of Thailand","abac@au.edu","592/3 Soi Ramkhamhaeng 24 Ramkhamhaeng Rd., Hua Mak, Bangkok 10240  Tel. (66) 0-2300-4543-62 Fax. (66) 0-2300-4563");
INSERT INTO `conference_email` VALUES("23","Thailand","Suan Dusit University","","295 Nakhon Ratchasima Rd, Khwaeng Dusit, Khet Dusit, ????????????? 10300, Thailand");



DROP TABLE IF EXISTS `intern`;

CREATE TABLE `intern` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `periode_tahun` varchar(255) NOT NULL,
  `photo` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `date_of_birth` date NOT NULL,
  `place_of_birth` varchar(255) NOT NULL,
  `gender` varchar(255) NOT NULL,
  `nationality` varchar(255) NOT NULL,
  `address` text NOT NULL,
  `zip_code` varchar(255) NOT NULL,
  `city` varchar(255) NOT NULL,
  `state` varchar(255) NOT NULL,
  `contry` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `last_university` varchar(255) NOT NULL,
  `passport_number` varchar(255) NOT NULL,
  `passport_issue` date NOT NULL,
  `passport_expiry` date NOT NULL,
  `passport_scan` varchar(255) NOT NULL,
  `visa_scan` varchar(255) NOT NULL,
  `start_internship` date NOT NULL,
  `end_internship` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;




DROP TABLE IF EXISTS `intern_file`;

CREATE TABLE `intern_file` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nama_intern` varchar(255) NOT NULL,
  `nama_file` varchar(255) NOT NULL,
  `keterangan_file` text NOT NULL,
  `file` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;




DROP TABLE IF EXISTS `mou`;

CREATE TABLE `mou` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `document_id` varchar(255) NOT NULL,
  `partner` varchar(255) NOT NULL,
  `program` text NOT NULL,
  `continent` varchar(255) NOT NULL,
  `country` varchar(255) NOT NULL,
  `start` date NOT NULL,
  `end` date NOT NULL,
  `scan` varchar(255) NOT NULL,
  `tanggal_input` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `id_user` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=latin1;

INSERT INTO `mou` VALUES("4","U/MY/UKM/1/2014","Universitas Kebangsaan Malaysia","","ASIA","Malaysia","2014-04-01","0000-00-00","","2018-04-18 06:50:16","Ikhsan Thohir");
INSERT INTO `mou` VALUES("6","U/KH/BIT/1/2016","Battambang Institute of Technology ( BIT )","","ASIA","Kamboja","0000-00-00","0000-00-00","","2018-04-18 06:51:34","Ikhsan Thohir");
INSERT INTO `mou` VALUES("7","U/KH/RPITSB/1/2016","Regional polytechnic institute techno sen battambang (RPITSB)","","ASIA","KAMBOJA","0000-00-00","0000-00-00","","2018-04-18 06:52:02","Ikhsan Thohir");
INSERT INTO `mou` VALUES("8","U/KH/RPITST/1/2016","Regional Polytechnic Institute Techo Sen Takeo (RPITST)","","ASIA","KAMBOJA","0000-00-00","0000-00-00","","2018-04-18 06:52:27","Ikhsan Thohir");
INSERT INTO `mou` VALUES("9","U/KZ/ELA/1/2016","Eurasian Law Academy","","ASIA","Khazakstan","0000-00-00","0000-00-00","","2018-04-18 06:52:59","Ikhsan Thohir");
INSERT INTO `mou` VALUES("10","U/KZ/AKNMU/1/2016","Aspendirayrov Kazakh National Medical University","","ASIA","Khazakstan","0000-00-00","0000-00-00","","2018-04-18 06:53:24","Ikhsan Thohir");
INSERT INTO `mou` VALUES("11","U/KZ/ZSU/1/2016","Zhetsyu State university","","ASIA","Khazakstan","0000-00-00","0000-00-00","","2018-04-18 06:53:57","Ikhsan Thohir");
INSERT INTO `mou` VALUES("12","U/KZ/KSWTTU/1/2016","Kazakh State Women’s Teacher Training University","","ASIA","Kazakstan","0000-00-00","0000-00-00","","2018-04-18 06:54:19","Ikhsan Thohir");
INSERT INTO `mou` VALUES("13","U/KZ/AKPU/1/2016","Abai Kazakh Pedagogical university","","ASIA","Kazakstan","0000-00-00","0000-00-00","","2018-04-18 06:55:14","Ikhsan Thohir");
INSERT INTO `mou` VALUES("15","U/KZ/KSWTTU/1/2016","Kazakh State Women’s Teacher Training University","","ASIA","Khazakstan","0000-00-00","0000-00-00","","2018-04-18 07:00:48","Ikhsan Thohir");
INSERT INTO `mou` VALUES("17","U/KZ/IIU/1/2016","International IT University","","ASIA","Khazakstan","0000-00-00","0000-00-00","","2018-04-18 07:01:39","Ikhsan Thohir");
INSERT INTO `mou` VALUES("18","U/KZ/AKNU/1/2106","Al-Farabi Kazakh National University","","ASIA","Khazakstan","0000-00-00","0000-00-00","","2018-04-18 07:01:59","Ikhsan Thohir");
INSERT INTO `mou` VALUES("19","U/KZ/AEL/1/2016","Academy Economic and Law","","ASIA","Khazakstan","0000-00-00","0000-00-00","","2018-04-18 07:02:25","Ikhsan Thohir");
INSERT INTO `mou` VALUES("20","U/KZ/KBTU/1/2106","Kazakh-British Technical University","","ASIA","Khazakstan","0000-00-00","0000-00-00","","2018-04-18 07:02:45","Ikhsan Thohir");
INSERT INTO `mou` VALUES("21","U/UZ/PRUBT/1/2016","Plekhanov Russian University Brand Tashkent","","ASIA","Uzbekistan","0000-00-00","0000-00-00","","2018-04-18 07:03:20","Ikhsan Thohir");
INSERT INTO `mou` VALUES("22","U/CN/LNU/1/2016","Leshan Normal University","","ASIA","China","0000-00-00","0000-00-00","","2018-04-18 07:03:59","Ikhsan Thohir");
INSERT INTO `mou` VALUES("23","U/CN/SCOAT/1/2016","Sinchuan College Of Architectural Technology","","ASIA","China","0000-00-00","0000-00-00","","2018-04-18 07:04:37","Ikhsan Thohir");
INSERT INTO `mou` VALUES("24","U/CN/SUST/1/2016","Soutwest University of Science and Technology","","ASIA","China","0000-00-00","0000-00-00","","2018-04-18 07:05:01","Ikhsan Thohir");
INSERT INTO `mou` VALUES("25","U/KR/SMU/1/2017","Sun Moon University","","ASIA","Korea Selatan","0000-00-00","0000-00-00","","2018-04-18 07:05:26","Ikhsan Thohir");



DROP TABLE IF EXISTS `setting`;

CREATE TABLE `setting` (
  `id` int(11) NOT NULL,
  `nama_website` varchar(255) NOT NULL,
  `logo` varchar(255) NOT NULL,
  `alamat` varchar(255) NOT NULL,
  `deskripsi` text NOT NULL,
  `theme` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `setting` VALUES("0","SIIRO NSP","LOGO-IRO.jpg","Jl Raya Ciboalang No 21","Sistem Informasi IRO","red");



DROP TABLE IF EXISTS `tbl_admin`;

CREATE TABLE `tbl_admin` (
  `admin_id` int(11) NOT NULL AUTO_INCREMENT,
  `admin_username` varchar(255) NOT NULL,
  `admin_password` varchar(255) NOT NULL,
  `admin_nama` varchar(255) NOT NULL,
  `admin_foto` varchar(255) NOT NULL,
  PRIMARY KEY (`admin_id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;

INSERT INTO `tbl_admin` VALUES("13","admin","21232f297a57a5a743894a0e4a801fc3","Ikhsan Thohir","qm39u4lbc408wo.jpg");
